package application;

import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;

import javafx.scene.control.ComboBox;

import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

public class GenerateNew implements Initializable {

    @FXML
    private ListView<String> academicCharacteristics;

    @FXML
    private Button cancelButton1;

    @FXML
    private TextField courseLettergrade;

    @FXML
    private ListView<String> courseTaken;

    @FXML
    private TextField firstName;

    @FXML
    private ComboBox<String> firstSemester;

    @FXML
    private TextField firstYear;

    @FXML
    private ComboBox<String> gender;

    @FXML
    private Button generateButton;

    @FXML
    private TextField lastName;

    @FXML
    private ListView<String> personalCharacteristics;

    @FXML
    private ComboBox<String> programApplying;

    @FXML
    private TextField schoolName;

    @FXML
    private Label warning;

    @FXML
    void userCancel1(ActionEvent event) {

    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    	 
    	String[] list = csvreader.readcsvfile("src/files/initial_data_.csv","gender");
        ObservableList<String> list_gender = FXCollections.observableArrayList(list);
        gender.setItems(list_gender);
        
        String[] list_program = csvreader.readcsvfile("src/files/initial_data_.csv","programs names");
        ObservableList<String> list_check = FXCollections.observableArrayList(list_program);
        programApplying.setItems(list_check);
        
         String[] firstSemesterList = csvreader.readcsvfile("src/files/initial_data_.csv","semesters");
         ObservableList<String> list_firstsemester = FXCollections.observableArrayList(firstSemesterList);
         firstSemester.setItems(list_firstsemester);
         
         String[] academicCharacteristicsList = csvreader.readcsvfile("src/files/initial_data_.csv","academic characteristics");
         ObservableList<String> list_academic = FXCollections.observableArrayList(academicCharacteristicsList);
         academicCharacteristics.getItems().addAll(list_academic);
         academicCharacteristics.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
         //gender.getSelectionModel().selectedItemProperty().addListener(this::selectionChanged);
         
         String[] personalCharacteristicsList = csvreader.readcsvfile("src/files/initial_data_.csv","personal characteristics");
         ObservableList<String> list_personalCharacter = FXCollections.observableArrayList(personalCharacteristicsList);
         personalCharacteristics.getItems().addAll(list_personalCharacter);
         personalCharacteristics.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
         //personalCharacteristics.getSelectionModel().selectedItemProperty().addListener(this::selectionChanged);
         
         String[] courseTakenList = csvreader.readcsvfile("src/files/initial_data_.csv","courses");
         ObservableList<String> list_course = FXCollections.observableArrayList(courseTakenList);
         courseTaken.getItems().addAll(list_course);
         courseTaken.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
         //courseTaken.getSelectionModel().selectedItemProperty().addListener(this::selectionChanged);
         
    }  
    
    @FXML
    void userGenerateNew(ActionEvent event) throws IOException {
		Main m = new Main();
		m.changeScene("ResetPassword.fxml");

    }

}







































//package application;
//import javafx.beans.value.ObservableValue;
//import javafx.collections.ObservableList;
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.fxml.Initializable;
//import javafx.scene.control.Label;
//import javafx.scene.control.ListView;
//import javafx.scene.control.SelectionMode;
//import java.net.URL;
//import java.util.ResourceBundle;
//import javafx.collections.FXCollections;
//
//import javafx.scene.control.ComboBox;
//
//import javafx.scene.control.Button;
//import javafx.scene.control.ChoiceBox;
//import javafx.scene.control.TextField;
//
//public class GenerateNew implements Initializable{
//
//    @FXML
//    private ComboBox<String> academicCharacteristics;
//
//    @FXML
//    private Button cancelButton1;
//
//    @FXML
//    private TextField courseLettergrade;
//
//    @FXML
//    private ListView<String> courseTaken;
//
//    @FXML
//    private TextField firstName;
//
//    @FXML
//    private ComboBox<String> firstSemester;
//
//    @FXML
//    private TextField firstYear;
//
//    @FXML
//    private ComboBox<String> gender;
//
//    @FXML
//    private Button generateButton;
//
//    @FXML
//    private TextField lastName;
//
//    @FXML
//    private ListView<String> personalCharacteristics;
//
//    @FXML
//    private ListView<String> programApplying;
//
//    @FXML
//    private TextField schoolName;
//
//    @FXML
//    private Label warning;
//
//    @FXML
//    void listGender(ActionEvent event) {
//    	String s = gender.getSelectionModel().getSelectedItem().toString();
//    }   
//    
//    
//    // initialize:- Fetches the attributes values using readcsvfile method of csvreader class and shows in drop down buttons.
//    @Override
//    public void initialize(URL url, ResourceBundle rb) {
//    	 
//    	String[] list = csvreader.readcsvfile("C:\\Classes\\Sem 2\\CS146\\initial_data_.csv","academic characteristics");
//        ObservableList<String> list_gender = FXCollections.observableArrayList(list);
//        gender.setItems(list_gender);
//         String[] academicCharacteristicsList = csvreader.readcsvfile("C:\\Classes\\Sem 2\\CS146\\initial_data_.csv","academic characteristics");
//         ObservableList<String> list_academic = FXCollections.observableArrayList(academicCharacteristicsList);
//         academicCharacteristics.setItems(list_academic);
//         
//         String[] firstSemesterList = csvreader.readcsvfile("C:\\Classes\\Sem 2\\CS146\\initial_data_.csv","semesters");
//         ObservableList<String> list_firstsemester = FXCollections.observableArrayList(firstSemesterList);
//         firstSemester.setItems(list_firstsemester);
//         
//         String[] programApplyingList = csvreader.readcsvfile("C:\\Classes\\Sem 2\\CS146\\initial_data_.csv","programs names");
//         ObservableList<String> list_programApplying = FXCollections.observableArrayList(programApplyingList);
//         programApplying.getItems().addAll(list_programApplying);
//         programApplying.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
//         //gender.getSelectionModel().selectedItemProperty().addListener(this::selectionChanged);
//         
//         String[] personalCharacteristicsList = csvreader.readcsvfile("C:\\Classes\\Sem 2\\CS146\\initial_data_.csv","personal characteristics");
//         ObservableList<String> list_personalCharacter = FXCollections.observableArrayList(personalCharacteristicsList);
//         personalCharacteristics.getItems().addAll(list_personalCharacter);
//         personalCharacteristics.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
//         //personalCharacteristics.getSelectionModel().selectedItemProperty().addListener(this::selectionChanged);
//         
//         String[] courseTakenList = csvreader.readcsvfile("C:\\Classes\\Sem 2\\CS146\\initial_data_.csv","courses");
//         ObservableList<String> list_course = FXCollections.observableArrayList(courseTakenList);
//         courseTaken.getItems().addAll(list_course);
//         courseTaken.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
//         //courseTaken.getSelectionModel().selectedItemProperty().addListener(this::selectionChanged);
//         
//    }    
//    
//    // selectionChanged:- Used for storing user selected inputs in database.
//    private void selectionChanged(ObservableValue<? extends String> Observable, String oldVal, String newVal){
//        //ObservableList<String> selectedItems = gender.getSelectionModel().getSelectedItems();
//        //String getSelectedItem = (selectedItems.isEmpty())?"No Selected Item":selectedItems.toString();
//        
//    }
//    @FXML
//    void userCancel1(ActionEvent event) {
//
//    }
//
//    @FXML
//    void userGenerateNew(ActionEvent event) {
//
//    }
//
//}
