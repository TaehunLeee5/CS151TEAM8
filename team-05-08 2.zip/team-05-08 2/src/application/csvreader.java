package application;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Arrays;
 

public class csvreader {
	
	// readcsvfile:- read the initial data file and send values for different attributes like gender,courses,etc.
	public static String[] readcsvfile(String filePath,String colName) {
		BufferedReader reader = null;
		try {
			
			String line = "";
			reader = new BufferedReader(new FileReader(filePath));
			while((line = reader.readLine()) != null) {
			    String[] fields = line.split(",");
			    if(fields[0].equalsIgnoreCase(colName)) {
			    	return Arrays.copyOfRange(fields, 1, fields.length);
			    }
			}
		} 
		catch (Exception ex) {
				   ex.printStackTrace();
		} 
		finally {
			try {
			    reader.close();
			   } catch (Exception e) {
			    e.printStackTrace();
			   }
			  }
		
		return null;
		
	}
	
	
	// getPassword:- fecthes the current password from datafile.
	public String getPassword(int i) {
		BufferedReader reader = null;
		try {
			String filePath = "src/files/usercreds.csv";
			
			String line = "";
			reader = new BufferedReader(new FileReader(filePath));
			reader.readLine();
			line = reader.readLine();
			String[] fields = line.split(",");			
			String h = fields[i];
			return fields[i];
		} 
		catch (Exception ex) {
				   ex.printStackTrace();
		} 
		finally {
			try {
			    reader.close();
			   } catch (Exception e) {
			    e.printStackTrace();
			   }
			  }
		
		return null;
		
	}
}
